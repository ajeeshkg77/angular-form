(() => {
    angular.module('imgSlider')
    .controller('sliderController', function($scope) {
        
    })
})();