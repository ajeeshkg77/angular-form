(() => {
    angular.module('imgSlider', []);
})();